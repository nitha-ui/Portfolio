export const demoPortfolioIds = [
  "630f44611ddb0f899c66e399",
  "630f51c81ddb0f899c66e39a",
  "638e3ff00640c1002987cc1e",
];
