export const LOCALHOST_URL = "http://localhost:4050/api";

// export const HEROKU_BASE_URL =
//   "https://dynamic-portfolio-backend.herokuapp.com/api";

export const VERCEL_BASE_URL =
  "https://dynamic-portfolio-backend.vercel.app/api";

export const AWS_BASE_URL =
  "http://dynamicportfoliobackend-env.eba-4b3y4qar.us-east-1.elasticbeanstalk.com/api";

export const CYCLIC_BASE_URL = "https://cute-ruby-tuna-wrap.cyclic.app/api";
